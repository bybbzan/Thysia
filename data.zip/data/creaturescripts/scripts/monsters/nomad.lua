function onDeath(cid, corpse, deathList)
doCreateItem(13519, 1, getCreaturePosition(cid))
end