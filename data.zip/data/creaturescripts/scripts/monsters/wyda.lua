function onDeath(cid, corpse, deathList)
doCreatureSay(cid, "It seems this was just an illusion.", TALKTYPE_ORANGE_1)
end