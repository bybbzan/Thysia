function onDeath(cid, corpse, deathList)
doCreatureSay(cid, "I WILL RETURN!! My death will just be a door to await my homecoming, my physical hull will be... my... argh...", TALKTYPE_ORANGE_2)
end