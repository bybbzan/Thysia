function onUse(cid, item, fromPosition, itemEx, toPosition)
	return destroyItem(cid, itemEx, toPosition)
end
